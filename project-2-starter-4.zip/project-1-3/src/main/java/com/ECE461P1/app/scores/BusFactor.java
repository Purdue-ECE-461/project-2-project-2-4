package com.ECE461P1.app.scores;
import java.io.*;
import java.net.*;

public class BusFactor extends Score {
  static int i = 0;
  public BusFactor(String _owner, String _repo){
    super(_owner, _repo);
  }
  
  public void getBusFactor() {
    System.out.println("Calculating bus factor score...");
    try {
      //jcabi does not implement jsonArrays, using HttpURLConnection directly instead
      URL contributorsUrl = new URL(apiUrl + "/contributors");
      int respon = httpreq(contributorsUrl);
      HttpURLConnection conn = (HttpURLConnection) contributorsUrl.openConnection();
      conn.setRequestMethod("GET");
      conn.setRequestProperty("Authorization", "token " + System.getenv("GITHUB_TOKEN"));
      if (respon == 200) {
        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String tempLine = rd.readLine();
        String[] tempLineArr = tempLine.split("\"login\":", -1);
        i = (tempLineArr.length) - 1; //max from api is 30
        rd.close();
      }
    } catch (Exception e){
      System.out.println(e);
    }
    
    score = ((i >= 6) ? 1 : ((float) i / 6));
    i = 0; // reset static i for next url
  }
}